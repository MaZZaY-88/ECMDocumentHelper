﻿namespace ECMDocumentHelper.Models
{
    public class FilePathsRequest
    {
        public List<string> FilePaths { get; set; }  // A list of file paths for PDF generation
    }
}
