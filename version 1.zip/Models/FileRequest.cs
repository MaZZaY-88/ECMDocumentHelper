﻿namespace ECMDocumentHelper.Models
{
    public class FileRequest
    {
        public string FilePath { get; set; }  // The path to the file that needs to be converted
    }
}
