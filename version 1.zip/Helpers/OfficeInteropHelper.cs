﻿using ExcelApp = Microsoft.Office.Interop.Excel;
using OutlookApp = Microsoft.Office.Interop.Outlook;
using PowerPointApp = Microsoft.Office.Interop.PowerPoint;
using WordApp = Microsoft.Office.Interop.Word;
using Microsoft.Extensions.Configuration;
using System;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using PdfSharp.Pdf;
using PdfSharp.Pdf.IO;
using PdfSharp.Drawing;
using System.Collections.Generic;

namespace ECMDocumentHelper.Helpers
{
    public class OfficeInteropHelper
    {
        private readonly string _outputDirectory;
        private readonly string _pdfSaveDirectory;

        public OfficeInteropHelper(IConfiguration configuration)
        {
            _outputDirectory = configuration.GetSection("PdfSettings")["outputDirectory"];
            _pdfSaveDirectory = configuration.GetSection("PdfSettings")["pdfSaveDirectory"];

            if (!Directory.Exists(_outputDirectory))
            {
                Directory.CreateDirectory(_outputDirectory);
            }

            if (!Directory.Exists(_pdfSaveDirectory))
            {
                Directory.CreateDirectory(_pdfSaveDirectory);
            }
        }

        // Method to merge multiple PDF files into a single PDF
        public string MergePdfFiles(List<string> pdfFilePaths, string outputPdfFileName)
        {
            string fullOutputPath = Path.Combine(_outputDirectory, outputPdfFileName);

            using (var outputDocument = new PdfSharp.Pdf.PdfDocument())
            {
                foreach (var pdfFile in pdfFilePaths)
                {
                    using (var inputDocument = PdfSharp.Pdf.IO.PdfReader.Open(pdfFile, PdfDocumentOpenMode.Import))
                    {
                        foreach (var page in inputDocument.Pages)
                        {
                            outputDocument.AddPage(page);
                        }
                    }
                }

                outputDocument.Save(fullOutputPath);
            }

            return fullOutputPath;
        }

        // Method to imprint barcode on each page of a PDF
        public string ImprintBarcodeOnPdf(string inputPdfPath, string barcodeText)
        {
            string outputPdfPath = Path.Combine(_outputDirectory, $"{Guid.NewGuid()}_barcode.pdf");

            using (var inputDocument = PdfReader.Open(inputPdfPath, PdfDocumentOpenMode.Modify))
            {
                XFont barcodeFont = new XFont("Code128", 16);  // Barcode font
                XGraphics gfx;

                for (int i = 0; i < inputDocument.PageCount; i++)
                {
                    var page = inputDocument.Pages[i];
                    gfx = XGraphics.FromPdfPage(page, XGraphicsPdfPageOptions.Prepend);

                    // Calculate position for barcode (left side, middle of the page)
                    double x = 20;
                    double y = page.Height / 2;

                    // Rotate the graphics context to 90 degrees for barcode rotation
                    gfx.RotateAtTransform(90, new XPoint(x, y));

                    // Draw the barcode text (rotated by 90 degrees)
                    gfx.DrawString(barcodeText, barcodeFont, XBrushes.Black, new XRect(x, y - 50, page.Width, 50), XStringFormats.Center);

                    // Reset transformation
                    gfx.Restore();
                }

                inputDocument.Save(outputPdfPath);  // Save the PDF with barcode
            }

            return outputPdfPath;
        }

        public string ConvertWordToPdf(string wordFilePath)
        {
            var wordApp = new WordApp.Application();
            WordApp.Document doc = null;

            var outputPdfPath = Path.Combine(_outputDirectory, $"{Path.GetFileNameWithoutExtension(wordFilePath)}_{Guid.NewGuid()}.pdf");

            try
            {
                doc = wordApp.Documents.Open(wordFilePath);
                doc.ExportAsFixedFormat(outputPdfPath, WordApp.WdExportFormat.wdExportFormatPDF);
            }
            finally
            {
                doc?.Close();
                wordApp.Quit();
            }

            return outputPdfPath;
        }

        public string ConvertExcelToPdf(string excelFilePath)
        {
            var excelApp = new ExcelApp.Application();
            ExcelApp.Workbook workbook = null;

            var outputPdfPath = Path.Combine(_outputDirectory, $"{Path.GetFileNameWithoutExtension(excelFilePath)}_{Guid.NewGuid()}.pdf");

            try
            {
                workbook = excelApp.Workbooks.Open(excelFilePath);
                workbook.ExportAsFixedFormat(ExcelApp.XlFixedFormatType.xlTypePDF, outputPdfPath);
            }
            finally
            {
                workbook?.Close(false);
                excelApp.Quit();
            }

            return outputPdfPath;
        }

        public string ConvertPowerPointToPdf(string pptFilePath)
        {
            var pptApp = new PowerPointApp.Application();
            PowerPointApp.Presentation presentation = null;

            var outputPdfPath = Path.Combine(_outputDirectory, $"{Path.GetFileNameWithoutExtension(pptFilePath)}_{Guid.NewGuid()}.pdf");

            try
            {
                presentation = pptApp.Presentations.Open(pptFilePath, WithWindow: Microsoft.Office.Core.MsoTriState.msoFalse);
                presentation.SaveAs(outputPdfPath, PowerPointApp.PpSaveAsFileType.ppSaveAsPDF);
            }
            finally
            {
                presentation?.Close();
                pptApp.Quit();
            }

            return outputPdfPath;
        }

        public string ConvertOutlookMsgToPdf(string msgFilePath)
        {
            var outlookApp = new OutlookApp.Application();
            OutlookApp.MailItem mailItem = null;

            try
            {
                if (!Directory.Exists(_pdfSaveDirectory))
                {
                    throw new DirectoryNotFoundException($"The directory {_pdfSaveDirectory} does not exist.");
                }

                var beforePrintFiles = Directory.GetFiles(_pdfSaveDirectory).ToList();

                SetPDFCreatorAsDefault();
                mailItem = (OutlookApp.MailItem)outlookApp.Session.OpenSharedItem(msgFilePath);
                mailItem.PrintOut();

                var printedFilePath = WaitForNewFile(beforePrintFiles, _pdfSaveDirectory);
                if (string.IsNullOrEmpty(printedFilePath))
                {
                    throw new FileNotFoundException("No new PDF file was found after printing.");
                }

                return printedFilePath;
            }
            finally
            {
                if (mailItem != null)
                {
                    Marshal.ReleaseComObject(mailItem);
                }
                Marshal.ReleaseComObject(outlookApp);
            }
        }

        private string WaitForNewFile(List<string> beforePrintFiles, string pdfSaveDirectory)
        {
            for (int attempt = 0; attempt < 10; attempt++)
            {
                var afterPrintFiles = Directory.GetFiles(pdfSaveDirectory).ToList();
                var printedFiles = afterPrintFiles.Except(beforePrintFiles).ToList();

                if (printedFiles.Count == 1)
                {
                    return printedFiles[0];
                }
                else if (printedFiles.Count > 1)
                {
                    return printedFiles.OrderByDescending(f => File.GetLastWriteTime(f)).First();
                }

                System.Threading.Thread.Sleep(500);
            }

            return null;
        }

        [DllImport("winspool.drv", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern bool SetDefaultPrinter(string Name);

        public static void SetPDFCreatorAsDefault()
        {
            SetDefaultPrinter("PDFCreator");
        }
    }
}
