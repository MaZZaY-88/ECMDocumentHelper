﻿using ECMDocumentHelper.Services;
using ECMDocumentHelper.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;

namespace ECMDocumentHelper.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class DocumentsController : ControllerBase
    {
        private readonly PdfProcessingService _pdfProcessingService;

        public DocumentsController(PdfProcessingService pdfProcessingService)
        {
            _pdfProcessingService = pdfProcessingService;
        }

        // Existing GeneratePDF method (as requested)
        [HttpPost("generatepdf")]
        public IActionResult GeneratePdf([FromBody] FilePathsRequest request)
        {
            if (request.FilePaths == null || request.FilePaths.Count == 0)
            {
                return BadRequest(new { StatusCode = 0, Message = "No file paths provided." });
            }

            try
            {
                // The returned value is now the full path
                var fullOutputPath = _pdfProcessingService.ConvertFilesToMergedPdf(request.FilePaths);
                return Ok(new { StatusCode = 1, Message = "PDFs merged successfully.", OutputPath = fullOutputPath });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { StatusCode = 0, Message = $"Internal server error: {ex.Message}", Details = ex.InnerException?.Message });
            }
        }

        // Endpoint to imprint a barcode on the PDF
        [HttpPost("imprintbarcode")]
        public IActionResult ImprintBarcodeOnPdf([FromBody] BarcodeRequest request)
        {
            if (string.IsNullOrEmpty(request.FilePath) || string.IsNullOrEmpty(request.BarcodeText))
            {
                return BadRequest(new { StatusCode = 0, Message = "File path or barcode text is missing." });
            }

            try
            {
                var outputPdfPath = _pdfProcessingService.ImprintBarcodeOnPdf(request.FilePath, request.BarcodeText);
                return Ok(new { StatusCode = 1, Message = "Barcode imprinted successfully.", OutputPath = outputPdfPath });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { StatusCode = 0, Message = $"Internal server error: {ex.Message}", Details = ex.InnerException?.Message });
            }
        }

        // Other methods...
    }
}
